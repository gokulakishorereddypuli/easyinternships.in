@include('common.head')
@include('common.e_header')

@include('common.e_navbar')

@include('common.footer')
@include('common.foot')
