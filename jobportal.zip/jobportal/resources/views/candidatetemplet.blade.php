@include('common.head')
@include('common.c_header')

@include('common.c_navbar')

@include('common.footer')
@include('common.foot')
