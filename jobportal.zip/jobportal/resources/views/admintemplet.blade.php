@include('common.head')
@include('common.admin_header')

@include('common.admin_navbar')

@include('common.foot')
