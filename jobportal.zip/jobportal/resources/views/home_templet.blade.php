@include('common.head')
@include('common.header')


<main id="main">
@yield('main')
</main>

@include('common.footer')
@include('common.foot')
