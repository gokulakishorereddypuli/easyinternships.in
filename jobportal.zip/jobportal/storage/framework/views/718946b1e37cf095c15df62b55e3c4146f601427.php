<h1>Admin<h1>
<?php /**PATH C:\xampp\htdocs\jobportal\resources\views/Admin/adminhome.blade.php ENDPATH**/ ?>