<title>Admin Dashboard</title>




<?php $__env->startSection('main'); ?>
<a>fkjgkdnhdih</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.dashboard_templet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobportal\resources\views/Admin/dashboard.blade.php ENDPATH**/ ?>