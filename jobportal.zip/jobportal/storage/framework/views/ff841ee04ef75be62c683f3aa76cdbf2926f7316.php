<?php $__env->startSection('main'); ?>
 <form action="update-profile" class="dashboard-form" method="POST">
     <?php echo e(csrf_field()); ?>


     <input type="hidden" name="id" value=" <?php echo e($user->candidate_id); ?>">
    <div class="dashboard-section upload-profile-photo">
      <div class="update-photo">
        <img class="image" src="/images/user-1.jpg" alt="">
      </div>
      <div class="file-upload">
        <input type="file" class="file-input">Change Avatar
      </div>
    </div>
    <div class="dashboard-section basic-info-input">
      <h4><i data-feather="user-check"></i>Basic Info</h4>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Full Name</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="Full Name" name="FullName" value=" <?php echo e($user->FullName); ?>" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Phone</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="+91 12345 67890" name="Phone" value="<?php echo e($user->Phone); ?>"  required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Address</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="Full Address" name="Address" value="<?php echo e($user->Address); ?> "  required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Indestry Expertise</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="UI & UX Designer" name="IndustryExpertise" value="<?php echo e($user->IndustryExpertise); ?> "  required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">About Me</label>
        <div class="col-sm-9">
          <textarea class="form-control" placeholder="Introduce Yourself" name="AboutMe" required><?php echo e($user->AboutMe); ?></textarea>
        </div>
      </div>
    </div>
    <div class="dashboard-section basic-info-input">



      <div class="form-group row">
        <label class="col-sm-3 col-form-label"></label>
        <div class="col-sm-9">
          <button class="button" type="submit">Save Change</button>
        </div>
      </div>
    </div>

  </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('candidatetemplet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reddy\OneDrive\Desktop\laravel\jobportal\resources\views/Candidate/updateprofile.blade.php ENDPATH**/ ?>