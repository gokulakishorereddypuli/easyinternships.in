<?php $__env->startSection('main'); ?>
 <form action="#" class="dashboard-form">
    <div class="dashboard-section upload-profile-photo">
      <div class="update-photo">
        <img class="image" src="/images/user-1.jpg" alt="">
      </div>
      <div class="file-upload">
        <input type="file" class="file-input">Change Avatar
      </div>
    </div>
    <div class="dashboard-section basic-info-input">
      <h4><i data-feather="user-check"></i>Basic Info</h4>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Full Name</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="Full Name">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Username</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="@username">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Email Address</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="email@example.com">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Phone</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="+91 12345 67890">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Address</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="Full Address">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Indestry Expertise</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" placeholder="UI & UX Designer">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">About Me</label>
        <div class="col-sm-9">
          <textarea class="form-control" placeholder="Introduce Yourself"></textarea>
        </div>
      </div>
    </div>
    <div class="dashboard-section basic-info-input">



      <div class="form-group row">
        <label class="col-sm-3 col-form-label"></label>
        <div class="col-sm-9">
          <button class="button">Save Change</button>
        </div>
      </div>
    </div>

  </form>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('candidatetemplet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reddy\OneDrive\Desktop\laravel\jobportal\resources\views/CandidateDashboard/editprofile.blade.php ENDPATH**/ ?>