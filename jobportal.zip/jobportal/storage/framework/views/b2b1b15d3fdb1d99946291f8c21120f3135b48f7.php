<?php $__env->startSection('main'); ?>
 <?php echo e("v jhjh"); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('candidatetemplet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reddy\OneDrive\Desktop\laravel\jobportal\resources\views/CandidateDashboard/profile.blade.php ENDPATH**/ ?>