    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src=" js/jquery.min.js"></script>
    <script src=" js/popper.min.js"></script>
    <script src=" js/bootstrap.min.js"></script>
    <script src=" js/feather.min.js"></script>
    <script src=" js/bootstrap-select.min.js"></script>
    <script src=" js/jquery.nstSlider.min.js"></script>
    <script src=" js/owl.carousel.min.js"></script>
    <script src=" js/visible.js"></script>
    <script src=" js/jquery.countTo.js"></script>
    <script src=" js/chart.js"></script>
    <script src=" js/plyr.js"></script>
    <script src=" js/tinymce.min.js"></script>
    <script src=" js/slick.min.js"></script>
    <script src=" js/jquery.ajaxchimp.min.js"></script>

    <script src="js/custom.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC87gjXWLqrHuLKR0CTV5jNLdP4pEHMhmg"></script>
    <script src="js/map.js"></script>
<?php /**PATH C:\xampp\htdocs\jobportal\resources\views/common/foot.blade.php ENDPATH**/ ?>