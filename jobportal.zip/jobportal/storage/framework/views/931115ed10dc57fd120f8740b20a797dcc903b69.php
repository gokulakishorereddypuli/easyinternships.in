<h1>login admin page</h1>
<?php /**PATH C:\xampp\htdocs\jobportal\resources\views/Admin/login.blade.php ENDPATH**/ ?>